var searchData=
[
  ['obiekt_5fstatku_0',['obiekt_Statku',['../class_plansza.html#a05f95b49df83ca3d01a2b8911e9246f5',1,'Plansza']]],
  ['odczytaj_5finstrukcje_1',['odczytaj_Instrukcje',['../main_8cpp.html#a93fa4b83cb07c77096d9c451b3c0b195',1,'main.cpp']]]
];
