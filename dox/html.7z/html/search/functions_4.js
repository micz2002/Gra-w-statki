var searchData=
[
  ['odczytaj_5finstrukcje_0',['odczytaj_Instrukcje',['../main_8cpp.html#a93fa4b83cb07c77096d9c451b3c0b195',1,'main.cpp']]]
];
