var searchData=
[
  ['czypion_0',['czyPion',['../class_plansza.html#aed3ecf6587c2ecf09cd04900fb843ec5',1,'Plansza::czyPion()'],['../class_statek.html#af37a4ac62a8f043722385911a7d817ff',1,'Statek::czyPion()']]],
  ['czyzapelnione_1',['czyZapelnione',['../class_plansza.html#adadfa5b042756f94a855b66de9973ede',1,'Plansza']]]
];
