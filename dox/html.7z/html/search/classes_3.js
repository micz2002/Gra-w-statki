var searchData=
[
  ['plansza_0',['Plansza',['../class_plansza.html',1,'']]]
];
