var searchData=
[
  ['dlugosc_0',['dlugosc',['../class_statek.html#adfb615e5e6a451481ad854be0efdc25b',1,'Statek']]]
];
