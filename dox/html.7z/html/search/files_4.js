var searchData=
[
  ['plansza_2ecpp_0',['Plansza.cpp',['../_plansza_8cpp.html',1,'']]],
  ['plansza_2eh_1',['Plansza.h',['../_plansza_8h.html',1,'']]]
];
