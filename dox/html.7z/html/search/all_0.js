var searchData=
[
  ['aktualne_5fx_0',['aktualne_x',['../class_plansza.html#a2f9f147d09ab5e47505cad0dc52acfba',1,'Plansza']]],
  ['aktualne_5fy_1',['aktualne_y',['../class_plansza.html#aea14506fec5b8a002ed859084b584525',1,'Plansza']]]
];
