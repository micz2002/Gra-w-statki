var searchData=
[
  ['rozmiesc_5fstatki_0',['rozmiesc_Statki',['../class_plansza.html#ae8018bd92f4a48dd74405fd7013e080a',1,'Plansza']]],
  ['rysuj_1',['rysuj',['../class_plansza.html#a1484ad8a655a2421852acd6cfc64d0c1',1,'Plansza']]]
];
