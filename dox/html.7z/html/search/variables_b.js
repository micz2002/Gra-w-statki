var searchData=
[
  ['zatopione_5fstatki_0',['zatopione_Statki',['../class_plansza.html#a68b35200843bc1c67737de09b240acbf',1,'Plansza']]]
];
