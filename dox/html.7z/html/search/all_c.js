var searchData=
[
  ['x_0',['x',['../class_statek.html#a88763e5e8eb050f0dc44f01ecc7193ab',1,'Statek']]]
];
