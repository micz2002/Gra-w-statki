var searchData=
[
  ['jaki_5fstatek_5fi_5fpozycja_0',['jaki_Statek_i_Pozycja',['../class_plansza.html#a2ddded9ca30adbca7342f64f9c450945',1,'Plansza']]]
];
