var searchData=
[
  ['plansza_0',['Plansza',['../class_plansza.html',1,'Plansza'],['../class_plansza.html#a8351c4dbcc842c6bc3aa11897f43ff1a',1,'Plansza::Plansza()']]],
  ['plansza_2ecpp_1',['Plansza.cpp',['../_plansza_8cpp.html',1,'']]],
  ['plansza_2eh_2',['Plansza.h',['../_plansza_8h.html',1,'']]],
  ['pobierz_5fczypion_3',['pobierz_CzyPion',['../class_cztero_masztowiec.html#a109096e0db5defe28fb1c890528254a1',1,'CzteroMasztowiec::pobierz_CzyPion()'],['../class_dwu_masztowiec.html#a8ae01833d7172b9334912f9f0e326317',1,'DwuMasztowiec::pobierz_CzyPion()'],['../class_jedno_masztowiec.html#a3adce53c74bf348315bc9840537a0718',1,'JednoMasztowiec::pobierz_CzyPion()'],['../class_statek.html#a5f1b48beff4f758fd8391a2d29311584',1,'Statek::pobierz_CzyPion()']]],
  ['pobierz_5fdlugosc_4',['pobierz_Dlugosc',['../class_cztero_masztowiec.html#a99524358c785ec4dd94965668b5f6c32',1,'CzteroMasztowiec::pobierz_Dlugosc()'],['../class_dwu_masztowiec.html#a369edf6af93dbef37a080e68f2d3affe',1,'DwuMasztowiec::pobierz_Dlugosc()'],['../class_jedno_masztowiec.html#a92e0da1bc6a2697ebe3ef869984fbba9',1,'JednoMasztowiec::pobierz_Dlugosc()'],['../class_statek.html#a4614b8497b19df1075b96dccbbf2ca79',1,'Statek::pobierz_Dlugosc()']]],
  ['pobierz_5fszerokosc_5',['pobierz_Szerokosc',['../class_plansza.html#a757ecd81e94ef0d5908f0071957e3311',1,'Plansza']]],
  ['pobierz_5fwspolrzedna_5fx_6',['pobierz_Wspolrzedna_X',['../class_cztero_masztowiec.html#aa94ee256cbeaca443f86b9a9ea57e4ab',1,'CzteroMasztowiec::pobierz_Wspolrzedna_X()'],['../class_dwu_masztowiec.html#a7a8c0824436ca58dd6df5c58d45f41f4',1,'DwuMasztowiec::pobierz_Wspolrzedna_X()'],['../class_jedno_masztowiec.html#ab9dc04570d508d2e4fcf7db7362ff312',1,'JednoMasztowiec::pobierz_Wspolrzedna_X()'],['../class_statek.html#a22082d9f56c4025146e12c4919f1f12b',1,'Statek::pobierz_Wspolrzedna_X()']]],
  ['pobierz_5fwspolrzedna_5fy_7',['pobierz_Wspolrzedna_Y',['../class_cztero_masztowiec.html#a0a41dbbb364bc35dd1e641dc9aa37c39',1,'CzteroMasztowiec::pobierz_Wspolrzedna_Y()'],['../class_dwu_masztowiec.html#a73e0046622fbbfea4b0fe826c3276362',1,'DwuMasztowiec::pobierz_Wspolrzedna_Y()'],['../class_jedno_masztowiec.html#a2d8dd25fd3279925ea807a170e4a1e95',1,'JednoMasztowiec::pobierz_Wspolrzedna_Y()'],['../class_statek.html#adcd4f2b7ccd534e30d1ef37b12be152b',1,'Statek::pobierz_Wspolrzedna_Y()']]],
  ['pobierz_5fwysokosc_8',['pobierz_Wysokosc',['../class_plansza.html#a1f0071e0840908b249b487634bc49c10',1,'Plansza']]],
  ['pobierz_5fzatopione_5fstatki_9',['pobierz_zatopione_Statki',['../class_plansza.html#a6fb37a8c9fe0567de85019466378932d',1,'Plansza']]],
  ['poleplanszy_10',['polePlanszy',['../class_plansza.html#a0a81cfaa73670bb6318a89030925ee95',1,'Plansza']]],
  ['przebieg_5fgry_11',['przebieg_Gry',['../main_8cpp.html#a92c800f45d85c3d7a8ae71d3fb3a4d22',1,'main.cpp']]],
  ['przygotowanie_5fgry_12',['przygotowanie_Gry',['../main_8cpp.html#afc5a162a9c28aa85eb0b2f22ba81a853',1,'main.cpp']]]
];
