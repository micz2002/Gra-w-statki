var searchData=
[
  ['wysokosc_0',['wysokosc',['../class_plansza.html#ad51d5225574d7a36d3feedf9d1f67712',1,'Plansza']]]
];
