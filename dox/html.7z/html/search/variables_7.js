var searchData=
[
  ['strzelaj_5fwkolo_0',['strzelaj_Wkolo',['../class_plansza.html#add105f5fb0395522259e7fea6278b990',1,'Plansza']]],
  ['szerokosc_1',['szerokosc',['../class_plansza.html#aaec68cf623afbb7f2f9e10fc030843e5',1,'Plansza']]]
];
