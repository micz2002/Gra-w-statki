var searchData=
[
  ['licznik_5fczteromasztowca_0',['licznik_CzteroMasztowca',['../class_plansza.html#a546ba68e5d094515bafaa4845014221d',1,'Plansza']]],
  ['licznik_5fdwumasztowca_1',['licznik_DwuMasztowca',['../class_plansza.html#a00b2f4571e5d22ce98cdd1cae6d9fda7',1,'Plansza']]],
  ['losuj_5forientacje_5fczteromasztowca_2',['losuj_Orientacje_Czteromasztowca',['../class_plansza.html#a0beb707fa8fff157a6034be0b4011284',1,'Plansza']]],
  ['losuj_5forientacje_5fdwumasztowca_3',['losuj_Orientacje_Dwumasztowca',['../class_plansza.html#a0a5f2024a97711e4bc1e66c07a0660c1',1,'Plansza']]]
];
