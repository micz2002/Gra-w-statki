var searchData=
[
  ['poleplanszy_0',['polePlanszy',['../class_plansza.html#a0a81cfaa73670bb6318a89030925ee95',1,'Plansza']]]
];
