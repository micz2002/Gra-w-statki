var searchData=
[
  ['obiekt_5fstatku_0',['obiekt_Statku',['../class_plansza.html#a05f95b49df83ca3d01a2b8911e9246f5',1,'Plansza']]]
];
