var searchData=
[
  ['statek_0',['Statek',['../class_statek.html#acda21999e42fb2c6038f343cc9668407',1,'Statek']]],
  ['strzelaj_1',['strzelaj',['../class_plansza.html#a4b148e197dbc77ffbc302a8b84603ba3',1,'Plansza']]],
  ['strzelaj_5fponownie_2',['strzelaj_Ponownie',['../class_plansza.html#a2f828742e60bb88175fc85a2dc0b64e1',1,'Plansza']]],
  ['stworz_5fczteromasztowiec_3',['stworz_CzteroMasztowiec',['../class_plansza.html#a5ae8316db0ba0b8af967187aadc076fe',1,'Plansza']]],
  ['stworz_5fdwumasztowiec_4',['stworz_DwuMasztowiec',['../class_plansza.html#a2c98af5151abe2af2accbe7f6b0b5b95',1,'Plansza']]],
  ['stworz_5fjednomasztowiec_5',['stworz_JednoMasztowiec',['../class_plansza.html#a125a99353ee43af8ed8ec58b7f1240ec',1,'Plansza']]]
];
