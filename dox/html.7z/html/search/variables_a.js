var searchData=
[
  ['y_0',['y',['../class_statek.html#a1d5696e96c4dd3b2d8151bf866d8fb3a',1,'Statek']]]
];
